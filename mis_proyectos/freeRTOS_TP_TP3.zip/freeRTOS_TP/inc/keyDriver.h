 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Evitar inclusion multiple comienzo]==================================*/

#ifndef _KEYDRIVER_H_
#define _KEYDRIVER_H_

/*=====[Inclusiones de dependencias de funciones publicas]===================*/


#include "FreeRTOS.h"
#include "FreeRTOSConfig.h"
#include "task.h"			//API de control de tareas y temporizacion
#include "semphr.h"			//API de sincronizacion (sem y mutex)
#include "queue.h"			//API de Colas
#include "event_groups.h" //Api de Grupos de eventos
#include "timers.h" //Api de Timers
#include <stdio.h>
#include "sapi.h"

/*=====[C++ comienzo]========================================================*/
#ifdef __cplusplus
extern "C" {
#endif

/*=====[Macros de definicion de constantes publicas]=========================*/
#define TIMEOUT_TIMER_DRIVER_KEY pdMS_TO_TICKS(100)

/*=====[Macros estilo funcion publicas]======================================*/
/*=====[Definiciones de tipos de datos publicos]=============================*/


//Timer de TIME_OUT
TimerHandle_t TimerDriverKey;

typedef enum {
	STATE_BUTTON_UP,
	STATE_BUTTON_DOWN,
	STATE_BUTTON_FALLING,
	STATE_BUTTON_RISING

} FsmButtonState_t;

typedef struct {
	gpioMap_t tec;
	FsmButtonState_t state;
	bool_t flagFalling;
	bool_t flagRising;

}Button_t;

Button_t btn1;
Button_t btn2;
Button_t btn3;
Button_t btn4;

/*=====[Prototipos de funciones publicas]====================================*/

void driverKeyInit(void);
void buttonInit(Button_t* btn, gpioMap_t tec,
	FsmButtonState_t state, bool_t flagFalling, bool_t flagRising);
void FsmButtonUpdate(Button_t* btn);
void TimerDriverKeyCallback (TimerHandle_t xTimerDriverKey);

/*=====[Prototipos de funciones publicas de interrupcion]====================*/
/*=====[C++ fin]=============================================================*/
#ifdef __cplusplus
}
#endif
/*=====[Evitar inclusion multiple fin]=======================================*/
#endif /* _KEYDRIVER_H_ */
