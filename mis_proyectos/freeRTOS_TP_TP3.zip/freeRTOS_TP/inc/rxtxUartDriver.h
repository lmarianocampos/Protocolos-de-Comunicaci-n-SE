 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Evitar inclusion multiple comienzo]==================================*/

#ifndef _RX_TX_UART_DRIVER_H_
#define _RX_TX_UART_DRIVER_H_

/*=====[Inclusiones de dependencias de funciones publicas]===================*/
#include "FreeRTOS.h"
#include "FreeRTOSConfig.h"
#include "task.h"			//API de control de tareas y temporizacion
#include "semphr.h"			//API de sincronizacion (sem y mutex)
#include "queue.h"			//API de Colas
#include <sapi.h>


#include "servicioProcesamientoTexto.h"
#include "fsmMedirPerformance.h"


/*=====[C++ comienzo]========================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/*=====[Macros de definicion de constantes publicas]=========================*/
/*=====[Macros estilo funcion publicas]======================================*/

/*=====[Definiciones de tipos de datos publicos]=============================*/
QueueHandle_t xQueueRecepcion, xQueueTransmitir_UART;
uint32_t tiempoDeLLegada;
uint32_t tiempoDeRecepcion;

void driverInit(void);
//Funcion de inicializacion de interrupciones
void IRQ_Init(void);
// Funcion Handler de ISR UART_USB de Recepcion
void datoRecibido(void *noUsado);
// Funcion Handler de ISR UART_USB de Transmision
void datoEnviado(void *noUsado);

/*=====[Prototipos de funciones publicas]====================================*/

/*=====[Prototipos de funciones publicas de interrupcion]====================*/

/*=====[C++ fin]=============================================================*/
#ifdef __cplusplus
}
#endif
/*=====[Evitar inclusion multiple fin]=======================================*/
#endif /* _RX_TX_UART_DRIVER_H_ */
