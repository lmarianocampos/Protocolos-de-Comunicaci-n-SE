 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Inclusion de su propia cabecera]=====================================*/

#include "rxtxUartDriver.h"
//#include <sapi.h>


//#define TAMANIO_MAXIMO_PAQUETE 104
//#define TAMANIO_COLAS_PUNTEROS 5

void IRQ_Init(void) {
	/* Inicializar la UART_USB junto con las interrupciones de  Rx */
	uartConfig(UART_USB, 115200);
	// Seteo un callback al evento de recepcion y habilito su interrupcion
	uartCallbackSet(UART_USB, UART_RECEIVE, datoRecibido, NULL);
//	uartCallbackSet(UART_USB, UART_TRANSMITER_FREE, datoEnviado, NULL);
	// Habilito todas las interrupciones de UART_USB
	uartInterrupt(UART_USB, TRUE);

}


void driverInit(){

	//Creacion de la colas
	xQueueRecepcion = xQueueCreate(TAMANIO_MAXIMO_PAQUETE, sizeof(char));
	if (xQueueRecepcion == NULL) {
		printf("No se pudo crear la COLA de recepcion de caracteres\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}

	xQueueTransmitir_UART = xQueueCreate(TAMANIO_COLAS_PUNTEROS,
			sizeof(char *));
	if (xQueueTransmitir_UART == NULL) {
		printf("No se pudo crear la COLA Transmitir_UART\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}
}

void datoEnviado(void *noUsado) {
	char *pDataToSend;//, *pDataToSendAux;
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;

	if (pdTRUE
			== xQueueReceiveFromISR(xQueueTransmitir_UART, &pDataToSend,
					&xHigherPriorityTaskWoken)) {
//		pDataToSendAux = pDataToSend;
//		if (operacion == 4)fsmMedirPerformance(pToken, T_SALIDA);
			uartWriteByte(UART_USB, '{');
			uartWriteString(UART_USB, pDataToSend);
			uartWriteByte(UART_USB, '}');
			uartWriteString(UART_USB,"\r\n");
//		if (operacion == 4)fsmMedirPerformance(pToken, T_TRANSMISION);
			uartCallbackClr(UART_USB, UART_TRANSMITER_FREE);

	}
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

// Implementacion de la funcion de Interrupcion datoRecibido activada por un dato en la FIFO de Rx
void datoRecibido(void *noUsado) {

	static uint8_t i = 0;
	static bool_t flag_guardar;
	uint8_t rx;
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;

	rx = uartRxRead(UART_USB);

	switch (rx) {
	case '{':
		tiempoDeLLegada =  xTaskGetTickCount();
		flag_guardar = TRUE;
		xQueueSendFromISR(xQueueRecepcion, &rx, &xHigherPriorityTaskWoken);
		i++;
		break;
	case '}':
		tiempoDeRecepcion =  xTaskGetTickCount();
		xQueueSendFromISR(xQueueRecepcion, &rx, &xHigherPriorityTaskWoken);
		i = 0;
		flag_guardar = FALSE;
		break;
	default:
		if (flag_guardar == TRUE && i < 104) {
			xQueueSendFromISR(xQueueRecepcion, &rx, &xHigherPriorityTaskWoken);
			i++;
		} else {
			i = 0;
			flag_guardar = FALSE;
		}
		break;
	}
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
