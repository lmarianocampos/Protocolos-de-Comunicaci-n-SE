 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Inclusion de su propia cabecera]=====================================*/

#include "fsmMedirPerformance.h"


//*=====[Inclusiones de dependencias de funciones privadas]===================*/


//void fsmMedirPerformanceInit(){}
void fsmMedirPerformance(token_t * pTokenTest, tiempo_t tiempoTest){

	switch (tiempoTest){
	case T_LLEGADA:
			pTokenTest->tiempo_de_llegada=xTaskGetTickCount();
		break;
	case T_RECEPCION:
			pTokenTest->tiempo_de_recepcion=xTaskGetTickCount();
		break;
	case T_INICIO:
			pTokenTest->tiempo_de_inicio=xTaskGetTickCount();
		break;
	case T_FIN:
			pTokenTest->tiempo_de_fin=xTaskGetTickCount();
		break;
	case T_SALIDA:
			pTokenTest->tiempo_de_salida=xTaskGetTickCount();
		break;
	case T_TRANSMISION:
			pTokenTest->tiempo_de_transmision=xTaskGetTickCount();
		break;
	}

}




