 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Inclusion de su propia cabecera]=====================================*/

#include "heartbeat.h"

//*=====[Inclusiones de dependencias de funciones privadas]===================*/
#include <sapi.h>
#include <string.h>

void heartBeatInit(void){

	// Creacion  tarea myTask
	xTaskCreate(myTask,                     // Funcion de la tarea a ejecutar
			(const char *) "myTask", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);



}



// Implementacion de funcion de la tarea
void myTask(void* taskParmPtr) {
	// ---------- CONFIGURACIONES ------------------------------
	// Tarea periodica cada 1000 ms
	portTickType xPeriodicity = 1000 / portTICK_RATE_MS;
	portTickType xLastWakeTime = xTaskGetTickCount();

	// ---------- REPETIR POR SIEMPRE --------------------------
	while (TRUE) {
		gpioToggle(LEDB);
		// Envia la tarea al estado bloqueado durante xPeriodicity (delay periodico)
		vTaskDelayUntil(&xLastWakeTime, xPeriodicity);
	}
}
