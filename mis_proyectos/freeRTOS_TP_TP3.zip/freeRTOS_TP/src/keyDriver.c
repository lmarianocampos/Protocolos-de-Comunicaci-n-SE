 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*==================[inlcusiones]============================================*/
#include "keyDriver.h"
/*==================[definiciones y macros]==================================*/

/*==================[definiciones de datos internos]=========================*/
/*==================[definiciones de datos externos]=========================*/
/*==================[declaraciones de funciones internas]====================*/
/*==================[declaraciones de funciones externas]====================*/
/*==================[declaraciones de variables privadas globales]=============================*/


void driverKeyInit(void) {
	// Creación de timer TIME_OUT
	if (NULL == (TimerDriverKey = xTimerCreate("Timer TimerDriverKey", //Nombre del timer en texto para debugging
			TIMEOUT_TIMER_DRIVER_KEY , //Período del timer en ticks
			pdTRUE, //Auto reiniciar el timer una vez expirado
			(void *) 0, //pvTimerID es un contador de cuántas veces ha expirado el timer inicializamos en 0
			TimerDriverKeyCallback //Callback que va a correr al expirar el timer
			))) {
		printf(
				"No se pudo crear el Timer_Driver_Key por falta de memoria en el HEAP\r\n");
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}

	buttonInit(&btn1, TEC1, STATE_BUTTON_UP, FALSE, FALSE);
	buttonInit(&btn2, TEC2, STATE_BUTTON_UP, FALSE, FALSE);
	buttonInit(&btn3, TEC3, STATE_BUTTON_UP, FALSE, FALSE);
	buttonInit(&btn4, TEC4, STATE_BUTTON_UP, FALSE, FALSE);
	xTimerStart( TimerDriverKey, 0 );

}

void buttonInit(Button_t* btn, gpioMap_t tec,
	FsmButtonState_t state, bool_t flagFalling, bool_t flagRising) {

	btn->tec = tec;
	btn->state = state;
	btn->flagFalling = flagFalling;
	btn->flagRising = flagRising;

}

void TimerDriverKeyCallback (TimerHandle_t xTimerDriverKey){

	//Encolamos evento de Timeout DRIVER_KEY
//	DespacharEvento(TIMEOUT_DRIVER_KEY);
	gpioToggle(LED1);
		FsmButtonUpdate(&btn1);
		FsmButtonUpdate(&btn2);
		FsmButtonUpdate(&btn3);
		FsmButtonUpdate(&btn4);


}


void FsmButtonUpdate(Button_t* btn) {
	switch (btn->state) {

	case STATE_BUTTON_UP:
		if (!gpioRead(btn->tec)) {
			btn->state = STATE_BUTTON_FALLING;

		}
		break;
	case STATE_BUTTON_DOWN:
		if (gpioRead(btn->tec)) {
			btn->state = STATE_BUTTON_RISING;

		}
		break;

	case STATE_BUTTON_FALLING:	//flanco negativo
		if (btn->flagFalling == FALSE) {
			btn->flagFalling = TRUE;
		}

			if (!gpioRead(btn->tec)) {
				btn->state = STATE_BUTTON_DOWN;
				gpioWrite(LED2,ON);
			} else {
				btn->state = STATE_BUTTON_UP;
			}
		if (btn->state != STATE_BUTTON_FALLING) {
			btn->flagFalling = FALSE;
		}

		break;
	case STATE_BUTTON_RISING:
		if (btn->flagRising == FALSE) {
			btn->flagRising = TRUE;
		}

			if (gpioRead(btn->tec)) {
				btn->state = STATE_BUTTON_UP;
				gpioWrite(LED2,OFF);
			} else {
				btn->state = STATE_BUTTON_DOWN;
			}
		if (btn->state != STATE_BUTTON_RISING) {
			btn->flagRising = FALSE;
		}
		break;

	}

}

/*==================[funcion principal]======================================*/


/*==================[definiciones de funciones internas]=====================*/
/*==================[definiciones de funciones externas]=====================*/
/*==================[fin del archivo]========================================*/
