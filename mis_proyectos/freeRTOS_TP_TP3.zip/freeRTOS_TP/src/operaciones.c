 /*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Inclusion de su propia cabecera]=====================================*/

#include "operaciones.h"

//*=====[Inclusiones de dependencias de funciones privadas]===================*/



void operacionesInit(void){

	xQueueMayusculizar = xQueueCreate(TAMANIO_COLAS_PUNTEROS, sizeof(char *)); //ver de pasar un puntero al inicio del arreglo
	if (xQueueMayusculizar == NULL) {
		printf("No se pudo crear la COLA Mayusculizar\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}
	xQueueMinusculizar = xQueueCreate(TAMANIO_COLAS_PUNTEROS, sizeof(char *)); //ver de pasar un puntero al inicio del arreglo
	if (xQueueMinusculizar == NULL) {
		printf("No se pudo crear la COLA Minusculizar\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}
	xQueueMedirPerformance = xQueueCreate(TAMANIO_COLAS_PUNTEROS, sizeof(char *)); //ver de pasar un puntero al inicio del arreglo
	if (xQueueMedirPerformance == NULL) {
		printf("No se pudo crear la COLA xQueueMedirPerformance\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}


	// Creacion  tareas Operacion0 Mayusculizar en freeRTOS
	xTaskCreate(operacion0,                    // Funcion de la tarea a ejecutar
			(const char *) "operacion0", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);
	// Creacion  tarea Operacion1 Minusculizar en freeRTOS
	xTaskCreate(operacion1,                    // Funcion de la tarea a ejecutar
			(const char *) "operacion1", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);

	// Creacion  tarea Operacion1 Minusculizar en freeRTOS
	xTaskCreate(operacion2,                    // Funcion de la tarea a ejecutar
			(const char *) "operacion2", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);

	// Creacion  tarea Operacion1 Minusculizar en freeRTOS
	xTaskCreate(operacion3,                    // Funcion de la tarea a ejecutar
			(const char *) "operacion3", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);


	// Creacion  tarea Operacion4 Medir Performance del Sistema (CMD/RTA)
	xTaskCreate(operacion4,                    // Funcion de la tarea a ejecutar
			(const char *) "operacion4", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);


	// Creacion  tarea Operacion5 Armo (RTA) Performance
		xTaskCreate(operacion5,                    // Funcion de la tarea a ejecutar
				(const char *) "operacion5", // Nombre de la tarea como String amigable para el usuario
				configMINIMAL_STACK_SIZE * 3, // Cantidad de stack de la tarea
				0,                          // Parametros de tarea
				tskIDLE_PRIORITY + 1,         // Prioridad de la tarea
				0                         // Puntero a la tarea creada en el sistema
				);
}


void operacion0 (void * taskParmPtr){
	char *pMayusculizar = NULL;
//	char rtastack[]="caca";
	uint8_t i =0;
	while (1) {
		if (pdTRUE == xQueueReceive(xQueueMayusculizar, &pMayusculizar,portMAX_DELAY)) {
			while (*(pMayusculizar+i) != '\0') {
				if (*(pMayusculizar+i) >= 'a' && *(pMayusculizar+i) <= 'z'){
					*(pMayusculizar+i) = *(pMayusculizar+i) - 32;
				}
				i++;
			}
			i=0;
			xQueueSend(xQueueTransmitir,&pMayusculizar,portMAX_DELAY);
	//		xQueueSend(xQueueTransmitir,rtastack,portMAX_DELAY);

		}
	}
}
void operacion1 (void* taskParmPtr){
	char *pMinusculizar = NULL;
	uint8_t i=0;
	while (1) {
		if (pdTRUE == xQueueReceive(xQueueMinusculizar, &pMinusculizar,portMAX_DELAY)) {
			while (*(pMinusculizar+i) != '\0') {
				if (*(pMinusculizar+i) >= 'A' && *(pMinusculizar+i) <= 'Z'){
					*(pMinusculizar+i) = *(pMinusculizar+i) + 32;
				}
				i++;
			}
			i=0;
			xQueueSend(xQueueTransmitir,&pMinusculizar,portMAX_DELAY);
		}
	}
}

void operacion2 (void * taskParmPtr){
char * cadena="2XXSTACK_DISPONIBLE:xxx";
	while(1){
		   if(xSemaphoreTake(semaphoreStackDisponible , portMAX_DELAY) == pdTRUE ){
			   xQueueSend(xQueueTransmitir,&cadena,portMAX_DELAY);
	}
}
}

void operacion3 (void * taskParmPtr){
char * cadena="3XXHEAP_DISPONIBLE:xxxx";
	while(1){
		   if(xSemaphoreTake(semaphoreHeapDisponible , portMAX_DELAY) == pdTRUE ){
			   xQueueSend(xQueueTransmitir,&cadena,portMAX_DELAY);
	}
}
}

void operacion4 (void * taskParmPtr){
	//TODO: (CMD/RTA) Usar codigo de operacion Mayusculizar y agregar una maquina de estados para ir guardando valores de performance en la estructura token
	// SUMAR A ESTE CODIGO UNA MAQUINA DE ESTADOS PARA MEDIR PERFORMANCE Y GRABAR ESOS DATOS EN LA ESTRUCTURA TOKEN
	token_t  *pTokenop = NULL;
	uint8_t i =0;
	while (1) {//aca recibo el token
		if (pdTRUE == xQueueReceive(xQueueMedirPerformance, &pTokenop,portMAX_DELAY)) {
			fsmMedirPerformance(pTokenop, T_INICIO);
			while (*(pTokenop->payload+i) != '\0') {
				if (*(pTokenop->payload+i) >= 'a' && *(pTokenop->payload+i) <= 'z'){
					*(pTokenop->payload+i) = *(pTokenop->payload+i) - 32;
				}
				i++;
			}
			i=0;
			fsmMedirPerformance(pTokenop, T_FIN);
			//Aca devuelvo el puntero a la cadena dinamica en vez del puntero al token.. ver si esto funciona
			xQueueSend(xQueueTransmitir,&(pTokenop->payload),portMAX_DELAY);
		}
	}
}


char* itoa(int value, char* result, int base) {
   // check that the base if valid
   if (base < 2 || base > 36) { *result = '\0'; return result; }

   char* ptr = result, *ptr1 = result, tmp_char;
   int tmp_value;

   do {
      tmp_value = value;
      value /= base;
      *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
   } while ( value );

   // Apply negative sign
   if (tmp_value < 0) *ptr++ = '-';
   *ptr-- = '\0';
   while(ptr1 < ptr) {
      tmp_char = *ptr;
      *ptr--= *ptr1;
      *ptr1++ = tmp_char;
   }
   return result;
}



void operacion5 (void * taskParmPtr){
	//Convertir estructura a cadena... si se ejecuta esto ya tiene todos los datos guardados!!!
char * cadena="5XXARMAR CADENA DINAMICA CON DATOS PERFORMANCE!";
//char * cadena_aux=NULL;
static char uartBuff[99], uartBuffAux[104];
uint8_t len;
char *p;
//uint32_t test=123;
p=uartBuffAux;

char tiempo_de_llegada[8];
char tiempo_de_recepcion[8];
char tiempo_de_inicio[8];
char tiempo_de_fin[8];
char tiempo_de_salida[8];
char tiempo_de_transmision[8];
char largo_del_paquete[8];
char memoria_alojada[8];
char len_cadena[8];


	while(1){
		   if(xSemaphoreTake(semaphorePerformance , portMAX_DELAY) == pdTRUE ){

			   memset(uartBuff,0,99);
			   memset(uartBuffAux,0,104);

			   itoa(pToken->tiempo_de_llegada,tiempo_de_llegada,10);
			   itoa(pToken->tiempo_de_recepcion,tiempo_de_recepcion,10);
			   itoa(pToken->tiempo_de_inicio,tiempo_de_inicio,10);
			   itoa(pToken->tiempo_de_fin,tiempo_de_fin,10);
			   itoa(pToken->tiempo_de_salida,tiempo_de_salida,10);
			   itoa(pToken->tiempo_de_transmision,tiempo_de_transmision,10);
			   itoa(pToken->largo_del_paquete,largo_del_paquete,10);
			   itoa(pToken->memoria_alojada,memoria_alojada,10);

			   strcpy(uartBuff,"TLL:");
			   strcat(uartBuff,tiempo_de_llegada);
			   strcat(uartBuff,"TR:");
			   strcat(uartBuff,tiempo_de_recepcion);
			   strcat(uartBuff,"TI:");
			   strcat(uartBuff,tiempo_de_inicio);
			   strcat(uartBuff,"TF:");
			   strcat(uartBuff,tiempo_de_fin);
			   strcat(uartBuff,"TS:");
			   strcat(uartBuff,tiempo_de_salida);
			   strcat(uartBuff,"TT:");
			   strcat(uartBuff,tiempo_de_transmision);
			   strcat(uartBuff,"LP:");
			   strcat(uartBuff,largo_del_paquete);
			   strcat(uartBuff,"MA:");
			   strcat(uartBuff,memoria_alojada);


			   len=strlen(uartBuff);
			   itoa(len,len_cadena,10);
			   strcat(uartBuffAux,"5");
			   strcat(uartBuffAux,len_cadena);
			   strcat(uartBuffAux,uartBuff);


			   xQueueSend(xQueueTransmitir,&p,portMAX_DELAY);
		   }
	}
}

