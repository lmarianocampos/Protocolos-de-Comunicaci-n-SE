/*
 * Copyright 2019 	Mariano Campos <author@mail.com>
 * 					Martin Gambarotta <magambarotta@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 * Version: 0.0.1
 * Fecha de creacion: 2019/07/25
 */

/*=====[Inclusion de su propia cabecera]=====================================*/

#include "servicioProcesamientoTexto.h"


/*=====[Inclusiones de dependencias de funciones privadas]===================*/


void servicioProcesamientoTextoInit(void) {

	semaphorePerformance=xSemaphoreCreateBinary();
	semaphoreStackDisponible=xSemaphoreCreateBinary();
	semaphoreHeapDisponible=xSemaphoreCreateBinary();

	xQueueTransmitir = xQueueCreate(TAMANIO_COLAS_PUNTEROS, sizeof(char *)); //ver de pasar un puntero al inicio del arreglo
	if (xQueueTransmitir == NULL) {
		printf("No se pudo crear la COLA Transmitir\n");
		gpioWrite(LED1, ON);
		while (1)
			;
		/* se queda bloqueado el sistema hasta
		 que venga el técnico de mantenmiento   */
	}

	// Creacion tarea procesamientoDatoRecibido
	xTaskCreate(procesamientoDatoRecibido,     // Funcion de la tarea a ejecutar
			(const char *) "procesamientoDatoRecibido", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 2,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);

	// Creacion  tarea Tranmision Dato Procesado en freeRTOS
	xTaskCreate(transmisionDatoProcesado,      // Funcion de la tarea a ejecutar
			(const char *) "transmisionDatoProcesado", // Nombre de la tarea como String amigable para el usuario
			configMINIMAL_STACK_SIZE * 2, // Cantidad de stack de la tarea
			0,                          // Parametros de tarea
			tskIDLE_PRIORITY + 2,         // Prioridad de la tarea
			0                         // Puntero a la tarea creada en el sistema
			);

}

// Implementacion de la Tarea  procesamientoDatoRecibido
void procesamientoDatoRecibido(void* taskParmPtr) {
	// ---------- CONFIGURACIONES ------------------------------
	portTickType xPeriodicity = 500 / portTICK_RATE_MS;
	uint8_t dato;
	static uint8_t cadenaprocesar[104];
	static uint8_t i = 0, flag_mensaje_finalizado;
	static validacion_datagrama_t datagrama;
	static uint8_t tamanio_cadena;
	uint32_t digitoUnidad, digitoDecimal, sizeTotal;
//	token_t * pToken = NULL;
	static uint32_t idPaquete = 0;
	char * cadena_dinamica;
    int32_t x;
    uint32_t memoria,memoria_alocada;
	// ---------- REPETIR POR SIEMPRE --------------------------
	while (TRUE) {
		if (pdTRUE == xQueueReceive(xQueueRecepcion, &dato, xPeriodicity)) {
			cadenaprocesar[i] = dato;
//			if ((i == 103)  && (cadenaprocesar[103] =! '}'))datagrama = DATAGRAMA_INVALIDO;  //TODO: ver que pasa si el cadena[103] no es }
			if (cadenaprocesar[i] == '}') {
				cadenaprocesar[i + 1] = '\0';
				flag_mensaje_finalizado = 1;
				datagrama = DATAGRAMA_VALIDO_OP;

				i = 0;
			} else
				i++;
		}
		if (flag_mensaje_finalizado == 1) {
			while (flag_mensaje_finalizado == 1) {
				switch (datagrama) {
				case DATAGRAMA_VALIDO_OP:
					switch (cadenaprocesar[1]) {
					case '0':
						operacion = 0;
						datagrama = DATAGRAMA_VALIDO_T;
						break;

					case '1':
						operacion = 1;
						datagrama = DATAGRAMA_VALIDO_T;
						break;

					case '4':
						operacion = 4;
						datagrama = DATAGRAMA_VALIDO_T;
						break;

					default:
						datagrama = DATAGRAMA_INVALIDO;
						break;
					}

					break;
				case DATAGRAMA_VALIDO_T:

					digitoUnidad = (uint32_t)(cadenaprocesar[3] - 48);
					digitoDecimal = (uint32_t)(cadenaprocesar[2] - 48) * 10;
					sizeTotal = digitoDecimal + digitoUnidad;

					tamanio_cadena = strlen(cadenaprocesar);
					if (sizeTotal == (tamanio_cadena - 5)) { //Resto todos los bytes fijos
						datagrama = DATAGRAMA_VALIDO;
					} else
						datagrama = DATAGRAMA_INVALIDO;
					break;
				case DATAGRAMA_VALIDO:
					flag_mensaje_finalizado = 0;
					//Resto los extremos  { } contemplo un espacio mas para el \0
					memoria=xPortGetFreeHeapSize();
					cadena_dinamica = pvPortMalloc(sizeof(char) * (tamanio_cadena - 1));
					if (cadena_dinamica == NULL) {
						printf(
								"No se pudo asignar memoria dinamica a la cadena recibida!\n");
						gpioWrite(LED1, ON);
						while (1)
							;
						/* se queda bloqueado el sistema hasta
						 que venga el técnico de mantenmiento   */
					}
					memoria_alocada=  memoria  - xPortGetFreeHeapSize();

					for (x = 0; x < (tamanio_cadena - 2); x++) {
						*(cadena_dinamica+x) = cadenaprocesar[x + 1];
					}
					*(cadena_dinamica+x) = '\0';

					if (operacion == 0) {
						xQueueSend(xQueueMayusculizar, &cadena_dinamica,
								portMAX_DELAY);
					} else if (operacion == 1) {
						xQueueSend(xQueueMinusculizar, &cadena_dinamica,
								portMAX_DELAY);
					}

					if (operacion == 4) {
						pToken = pvPortMalloc(sizeof(token_t));
						if (pToken == NULL) {
							printf(
									"Error en la asignación de memoria dinamica a la estrucutra TOKEN\n\r");
						} else {
							pToken->id_de_paquete = idPaquete;
							idPaquete++;
							pToken->tiempo_de_llegada = tiempoDeLLegada;
							pToken->tiempo_de_recepcion = tiempoDeRecepcion;
							pToken->payload = cadena_dinamica;
							pToken->largo_del_paquete=tamanio_cadena;
							pToken->memoria_alojada=memoria_alocada;
							xQueueSend(xQueueMedirPerformance, &pToken,
									portMAX_DELAY);
						}
					}

					break;
				case DATAGRAMA_INVALIDO:
					printf("Dato Invalido!\r\n");
					flag_mensaje_finalizado = 0;
					memset(cadenaprocesar, 0, 104); // esto creo q no es necesario
					break;

				default:
					break;
				}
			}
		}
	}
}

//void transmisionDatoProcesado(void* taskParmPtr) {
//	char *pdatoProcesado;
//	while (1) {
//		if (pdTRUE == xQueueReceive(xQueueTransmitir, &pdatoProcesado,
//		portMAX_DELAY)) {
//			xQueueSend(xQueueTransmitir_UART, &pdatoProcesado, portMAX_DELAY);
//			uartSetPendingInterrupt(UART_USB);
//			uartCallbackSet(UART_USB, UART_TRANSMITER_FREE, datoEnviado, NULL);
//			//Salta a la interrupcion - envia datos y al volver libera memoria
//			vPortFree(pdatoProcesado);
//
//		}
//	}
//}

void transmisionDatoProcesado(void* taskParmPtr) {
	char *pdatoProcesado;
	while (1) {
		if (pdTRUE == xQueueReceive(xQueueTransmitir, &pdatoProcesado,
		portMAX_DELAY)) {
			switch (operacion){
			case 0:
				envioDatoUartISR(pdatoProcesado);
				vPortFree(pdatoProcesado);
				operacion=2;
				xSemaphoreGive(semaphoreStackDisponible);
				break;
			case 1:
				envioDatoUartISR(pdatoProcesado);
				vPortFree(pdatoProcesado);
				operacion=2;
				xSemaphoreGive(semaphoreStackDisponible);
				break;
			case 2:
				envioDatoUartISR(pdatoProcesado);
				break;
			case 3:
				envioDatoUartISR(pdatoProcesado);
				break;
			case 4:
				fsmMedirPerformance(pToken, T_SALIDA);
				envioDatoUartISR(pdatoProcesado);
				fsmMedirPerformance(pToken, T_TRANSMISION);
				vPortFree(pdatoProcesado);
				operacion=5;
				xSemaphoreGive(semaphorePerformance);
				break;
			case 5:
				envioDatoUartISR(pdatoProcesado);
				vPortFree(pToken);
				break;
			default:
				break;
			}
		}
	}
}


void envioDatoUartISR (char *pdatoProcesado){
	xQueueSend(xQueueTransmitir_UART, &pdatoProcesado, portMAX_DELAY);
	uartSetPendingInterrupt(UART_USB);
	uartCallbackSet(UART_USB, UART_TRANSMITER_FREE, datoEnviado, NULL);
}


