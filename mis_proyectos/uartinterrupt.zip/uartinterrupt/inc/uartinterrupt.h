#ifndef _UARTINTERRUPT_H
#define	_UARTINTERRUPT_H

  #include "sapi.h"

  void onRx(void *noUsado);

#endif
