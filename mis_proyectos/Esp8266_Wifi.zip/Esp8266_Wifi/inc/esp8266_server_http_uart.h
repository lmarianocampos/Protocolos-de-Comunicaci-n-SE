#ifndef ESP8266_SERVER_HTTP_UART
#define ESP8266_SERVER_HTTP_UART

#include "sapi.h"
#include "esp8266_server_http.h"

void esp8266ReadUartUSB(void);

#endif
